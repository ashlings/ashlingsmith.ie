<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'c564718_gnilhsa');

/** MySQL database username */
define('DB_USER', 'c564718_ashsm');

/** MySQL database password */
define('DB_PASSWORD', 'SfBpJ0zC6vkh');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'pI} O5|,07:h2K+>}c5DZ7,2}=@Ey$U IFo^ZIEwQi<pIk|O?I5846EhslCc|I*b');
define('SECURE_AUTH_KEY',  'y}iZ=QG%dj#Of-~`^~uW&sY%#B{!F/WXQUJ) 5m5}@&Tv(`:25kCElwLE+u2~Ud]');
define('LOGGED_IN_KEY',    'Ve%3Y{wwW~@g?&](qo|#y]1A%V0JT6KAx&Cc<jeXta]Jy3{;@bS`/I,J#xx(I@$b');
define('NONCE_KEY',        '4Mo8Y4S/{tqTjyM$1/!mE6($lamE(rtp7uFo#:A;D0mN&`<m-J46M,?BUi`rrE4A');
define('AUTH_SALT',        'lS%-[T%nhe?yD)fK1M;=o,7xvWp@6)[s_fd?8w~}#6kyLw:9^#|+nPEj[h*n>/)0');
define('SECURE_AUTH_SALT', '?~Im1HBB=.>T HV0Z$6<#`/]oB%>B:FMD0A@$q&hy|Ahpic_UGJiGh&Zu];3StJ[');
define('LOGGED_IN_SALT',   'MRf4EBmxo3*R2ZR=MXJrI=KK9WZ Tgpu~_JpriJtCKsfEXGeQ{3BqUQqjie>GTuq');
define('NONCE_SALT',       'LB(46b+NgDSs^`0uLv=kw[BY:_,H5B,y_{~;JhYlSnr208aPM6g`FOVnKzydcO~a');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_gnilhsa';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
